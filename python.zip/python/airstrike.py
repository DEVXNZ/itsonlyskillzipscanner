import os
print("*******************************************")
print("*      SKIDO HACKS   ITSONLYSKILLZ        *")
print("*******************************************")






print("USE THIS TOOL IN YOUR OWN RESPONSIBILITY. EDUCATIONAL PERPOSES ONLY")




ip=(input("IP Address: "))
ping=os.system("ping "+str(ip))




